# Kinetic Experience v1: Sprint Breakdown

**Sprint:** kinetic-experience-v1
**Duration:** 2 weeks (3 epics)
**Start Date:** December 28, 2025

---

## Sprint Overview

| Epic | Focus | Duration | Deliverable |
|------|-------|----------|-------------|
| Epic 1 | Foundation & Route | 3 days | `/explore` route with shell |
| Epic 2 | Stream Rendering | 4 days | Chat functionality with glass |
| Epic 3 | Active Rhetoric | 3 days | Concepts + forks + pivot |

**Total:** 10 working days

---

## Epic 1: Foundation & Route

**Goal:** Establish the new component tree and route without any Terminal dependencies.

### Story 1.1: Create Directory Structure

**Task:** Create the KineticStream component directory structure.

**Files to CREATE:**
```
src/surface/components/KineticStream/
├── index.ts
├── ExploreShell.tsx
├── Stream/
│   ├── index.ts
│   ├── KineticRenderer.tsx
│   └── blocks/
│       └── index.ts
├── CommandConsole/
│   └── index.ts
└── hooks/
    └── index.ts
```

**Acceptance Criteria:**
- [ ] All directories exist
- [ ] Index files export empty placeholders
- [ ] No imports from `components/Terminal/`

**Tests:** None (structure only)

---

### Story 1.2: Create ExplorePage Route

**Task:** Create the `/explore` route that hosts the KineticStream experience.

**Files to CREATE:**
- `src/surface/pages/ExplorePage.tsx`

**Files to MODIFY:**
- `src/router/index.tsx` (add route)

**Implementation:**

```typescript
// src/surface/pages/ExplorePage.tsx
import React from 'react';
import { ExploreShell } from '../components/KineticStream';

const ExplorePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[var(--glass-void)]">
      <ExploreShell />
    </div>
  );
};

export default ExplorePage;
```

**Acceptance Criteria:**
- [ ] Route `/explore` renders without errors
- [ ] Page has dark background (glass-void)
- [ ] No 404 or routing errors

**Tests:**
- E2E: `tests/e2e/explore-route.spec.ts` — route loads

---

### Story 1.3: Create ExploreShell Container

**Task:** Create the main orchestrator component that manages stream state.

**Files to CREATE:**
- `src/surface/components/KineticStream/ExploreShell.tsx`

**Implementation Notes:**
- Import engagement hooks from `src/core/engagement/`
- Manage local stream state with `useState`
- Render placeholder KineticRenderer
- Render placeholder CommandConsole

**Props Interface:**
```typescript
interface ExploreShellProps {
  initialLens?: string;
  initialJourney?: string;
}
```

**Acceptance Criteria:**
- [ ] Component renders without errors
- [ ] Uses engagement machine context (if available)
- [ ] Manages `StreamItem[]` state
- [ ] No imports from `components/Terminal/`

**Tests:**
- Unit: `tests/unit/ExploreShell.test.tsx` — renders, manages state

---

### Story 1.4: Create useKineticStream Hook

**Task:** Create the hook that manages stream state and chat submission.

**Files to CREATE:**
- `src/surface/components/KineticStream/hooks/useKineticStream.ts`

**Implementation Notes:**
- Manages `StreamItem[]` array
- Handles message submission via `chatService`
- Converts responses to StreamItem format
- Parses navigation and rhetoric on completion

**Interface:**
```typescript
interface UseKineticStreamReturn {
  items: StreamItem[];
  currentItem: StreamItem | null;
  isLoading: boolean;
  submit: (query: string, pivot?: PivotContext) => Promise<void>;
  clear: () => void;
}
```

**Acceptance Criteria:**
- [ ] Submit adds query item immediately
- [ ] Response streams into current item
- [ ] Completion triggers parsing
- [ ] Uses existing parsers from `src/core/transformers/`

**Tests:**
- Unit: `tests/unit/useKineticStream.test.ts` — submit flow, parsing

---

### Epic 1 Build Gate

```bash
# Verify structure
ls src/surface/components/KineticStream/

# Verify no Terminal imports
grep -r "from.*components/Terminal" src/surface/components/KineticStream/
# Expected: empty

# Build passes
npm run build

# Route works
npm run dev &
curl -s http://localhost:5173/explore | grep -q "ExploreShell" && echo "Route OK"
```

---

## Epic 2: Stream Rendering

**Goal:** Implement the polymorphic renderer and object blocks with glass effects.

### Story 2.1: Create KineticRenderer

**Task:** Create the component that routes StreamItems to appropriate block components.

**Files to CREATE:**
- `src/surface/components/KineticStream/Stream/KineticRenderer.tsx`

**Implementation Notes:**
- Use `AnimatePresence` from framer-motion
- Switch on `item.type` to render appropriate block
- Pass interaction callbacks down

**Interface:**
```typescript
interface KineticRendererProps {
  items: StreamItem[];
  currentItem?: StreamItem | null;
  onConceptClick?: (span: RhetoricalSpan, sourceId: string) => void;
  onForkSelect?: (fork: JourneyFork) => void;
  onPromptSubmit?: (prompt: string) => void;
}
```

**Acceptance Criteria:**
- [ ] Routes all StreamItem types correctly
- [ ] AnimatePresence handles enter/exit
- [ ] Callbacks propagate to children

**Tests:**
- Unit: `tests/unit/KineticRenderer.test.tsx` — routing logic

---

### Story 2.2: Create GlassContainer

**Task:** Create the glass effect wrapper component.

**Files to CREATE:**
- `src/surface/components/KineticStream/Stream/motion/GlassContainer.tsx`
- `src/surface/components/KineticStream/Stream/motion/variants.ts`

**Implementation Notes:**
- CSS-only glass effect (no heavy backdrop-blur)
- Reuse tokens from `styles/globals.css`
- Support intensity variants: `subtle`, `medium`, `elevated`

**Interface:**
```typescript
interface GlassContainerProps {
  children: React.ReactNode;
  intensity?: 'subtle' | 'medium' | 'elevated';
  className?: string;
  variant?: 'default' | 'user' | 'assistant' | 'error';
}
```

**Acceptance Criteria:**
- [ ] Renders with proper glass background
- [ ] Supports all intensity levels
- [ ] Variant changes border/accent color
- [ ] No layout shift on hover

**Tests:**
- Visual: Playwright snapshot test

---

### Story 2.3: Create QueryObject

**Task:** Create the user message display component.

**Files to CREATE:**
- `src/surface/components/KineticStream/Stream/blocks/QueryObject.tsx`

**Implementation Notes:**
- Minimal styling (user messages are secondary)
- Right-aligned or subtle treatment
- Show pivot context if present

**Interface:**
```typescript
interface QueryObjectProps {
  item: QueryStreamItem;
}
```

**Acceptance Criteria:**
- [ ] Renders user text
- [ ] Shows pivot indicator if `item.pivot` exists
- [ ] Visually distinct from assistant messages

**Tests:**
- Unit: Basic render test

---

### Story 2.4: Create ResponseObject

**Task:** Create the AI response display component with streaming support.

**Files to CREATE:**
- `src/surface/components/KineticStream/Stream/blocks/ResponseObject.tsx`

**Implementation Notes:**
- Wrap in GlassContainer
- Render markdown when complete
- Show streaming indicator when `isGenerating`
- Render navigation forks at bottom
- Render concept spans (Story 3.1)

**Interface:**
```typescript
interface ResponseObjectProps {
  item: ResponseStreamItem;
  onConceptClick?: (span: RhetoricalSpan) => void;
  onForkSelect?: (fork: JourneyFork) => void;
  onPromptSubmit?: (prompt: string) => void;
}
```

**Acceptance Criteria:**
- [ ] Glass container renders correctly
- [ ] Markdown renders for complete responses
- [ ] Streaming shows character-by-character reveal
- [ ] Loading indicator shows when no content yet
- [ ] Forks render at bottom when present

**Tests:**
- Unit: Render states (loading, streaming, complete)
- E2E: Submit and see response

---

### Story 2.5: Create NavigationObject

**Task:** Create the fork button display component.

**Files to CREATE:**
- `src/surface/components/KineticStream/Stream/blocks/NavigationObject.tsx`

**Implementation Notes:**
- Group forks by type (deep_dive, pivot, apply, challenge)
- Style buttons by priority
- Trigger `onForkSelect` callback on click

**Interface:**
```typescript
interface NavigationObjectProps {
  forks: JourneyFork[];
  onSelect?: (fork: JourneyFork) => void;
}
```

**Button Hierarchy:**
| Type | Style | Icon |
|------|-------|------|
| deep_dive | Primary (clay) | ↓ |
| pivot | Secondary (surface) | → |
| apply | Tertiary (ghost) | ✓ |
| challenge | Quaternary (subtle) | ? |

**Acceptance Criteria:**
- [ ] Forks grouped by type
- [ ] Correct styling per type
- [ ] Click triggers callback with fork data
- [ ] Empty state returns null

**Tests:**
- Unit: Grouping logic, click handling

---

### Story 2.6: Create CommandConsole

**Task:** Create the floating input component.

**Files to CREATE:**
- `src/surface/components/KineticStream/CommandConsole/index.tsx`

**Implementation Notes:**
- Fixed position at bottom
- Glass styling for input area
- Submit on Enter
- Show loading state during generation

**Interface:**
```typescript
interface CommandConsoleProps {
  onSubmit: (query: string) => void;
  isLoading: boolean;
  placeholder?: string;
}
```

**Acceptance Criteria:**
- [ ] Input captures text
- [ ] Enter submits (unless Shift+Enter)
- [ ] Disabled during loading
- [ ] Visual feedback on submit

**Tests:**
- Unit: Submit handling
- E2E: Type and submit

---

### Story 2.7: Add Kinetic CSS Tokens

**Task:** Add CSS classes for fork buttons and kinetic-specific styles.

**Files to MODIFY:**
- `styles/globals.css`

**CSS to ADD:**
```css
/* ============================================================================
   Kinetic Stream Tokens
   Sprint: kinetic-experience-v1
   ============================================================================ */

/* Fork Buttons */
.kinetic-fork {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  font-size: 0.875rem;
  font-weight: 500;
  transition: all 0.2s ease;
  cursor: pointer;
}

.kinetic-fork:hover {
  transform: scale(1.05);
}

.kinetic-fork:active {
  transform: scale(0.95);
}

.kinetic-fork--primary {
  background: linear-gradient(135deg, var(--grove-clay), var(--grove-terracotta));
  color: white;
  box-shadow: 0 0 12px rgba(217, 119, 6, 0.3);
}

.kinetic-fork--secondary {
  background: var(--glass-surface);
  border: 1px solid var(--glass-border);
  color: var(--glass-text-body);
}

.kinetic-fork--tertiary {
  background: transparent;
  border: 1px solid var(--glass-border);
  color: var(--glass-text-subtle);
}

.kinetic-fork--quaternary {
  background: transparent;
  color: var(--glass-text-subtle);
  font-style: italic;
}

/* Concept Spans (Active Rhetoric) */
.kinetic-concept {
  color: var(--grove-clay);
  cursor: pointer;
  border-bottom: 1px solid transparent;
  transition: all 0.15s ease;
}

.kinetic-concept:hover {
  border-bottom-color: var(--grove-clay);
  text-shadow: 0 0 8px rgba(217, 119, 6, 0.3);
}

/* Command Console */
.kinetic-console {
  position: fixed;
  bottom: 1.5rem;
  left: 50%;
  transform: translateX(-50%);
  width: min(90vw, 48rem);
  z-index: 50;
}

.kinetic-console-input {
  width: 100%;
  background: var(--glass-solid);
  border: 1px solid var(--glass-border);
  border-radius: 1.5rem;
  padding: 1rem 1.5rem;
  color: var(--glass-text-primary);
  font-size: 1rem;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.kinetic-console-input:focus {
  border-color: var(--neon-cyan);
  box-shadow: 0 0 0 3px rgba(6, 182, 212, 0.15);
}

.kinetic-console-input::placeholder {
  color: var(--glass-text-subtle);
}
```

**Acceptance Criteria:**
- [ ] All token classes defined
- [ ] No conflicts with existing classes
- [ ] Consistent with glass design system

**Tests:**
- Visual: Playwright snapshots of styled components

---

### Epic 2 Build Gate

```bash
# Build passes
npm run build

# Unit tests pass
npm test -- --grep "Kinetic"

# E2E: Basic chat flow works
npx playwright test tests/e2e/explore-chat.spec.ts

# Visual regression
npx playwright test tests/e2e/explore-baseline.spec.ts
```

---

## Epic 3: Active Rhetoric

**Goal:** Implement concept highlighting and the pivot mechanic.

### Story 3.1: Create ConceptSpan Component

**Task:** Create the clickable concept highlight component.

**Files to CREATE:**
- `src/surface/components/KineticStream/ActiveRhetoric/ConceptSpan.tsx`

**Implementation Notes:**
- Wraps text in styled span
- Orange color from `--grove-clay`
- Click triggers callback with span data

**Interface:**
```typescript
interface ConceptSpanProps {
  span: RhetoricalSpan;
  onClick?: (span: RhetoricalSpan) => void;
}
```

**Acceptance Criteria:**
- [ ] Renders with orange styling
- [ ] Hover shows underline
- [ ] Click triggers callback
- [ ] Cursor indicates interactivity

**Tests:**
- Unit: Click handling

---

### Story 3.2: Create RhetoricRenderer

**Task:** Create the component that injects ConceptSpans into content.

**Files to CREATE:**
- `src/surface/components/KineticStream/ActiveRhetoric/RhetoricRenderer.tsx`

**Implementation Notes:**
- Takes content string and spans array
- Splits content at span boundaries
- Renders plain text and ConceptSpans
- Handles overlapping spans gracefully

**Interface:**
```typescript
interface RhetoricRendererProps {
  content: string;
  spans: RhetoricalSpan[];
  onSpanClick?: (span: RhetoricalSpan) => void;
}
```

**Acceptance Criteria:**
- [ ] Plain text renders between spans
- [ ] Spans render as ConceptSpan components
- [ ] Content order preserved
- [ ] Edge cases handled (empty spans, overlaps)

**Tests:**
- Unit: Span injection logic

---

### Story 3.3: Integrate Rhetoric into ResponseObject

**Task:** Wire RhetoricRenderer into ResponseObject.

**Files to MODIFY:**
- `src/surface/components/KineticStream/Stream/blocks/ResponseObject.tsx`

**Implementation Notes:**
- When `item.parsedSpans` exists, use RhetoricRenderer
- Otherwise, use plain MarkdownRenderer
- Pass `onConceptClick` through

**Acceptance Criteria:**
- [ ] Concepts render when spans present
- [ ] Falls back to plain markdown
- [ ] Click callback works

**Tests:**
- E2E: See orange text, click triggers action

---

### Story 3.4: Implement Pivot Mechanic

**Task:** Make concept clicks submit as new queries with pivot context.

**Files to MODIFY:**
- `src/surface/components/KineticStream/ExploreShell.tsx`
- `src/surface/components/KineticStream/hooks/useKineticStream.ts`

**Implementation Notes:**
- `onConceptClick` handler in ExploreShell
- Creates PivotContext with source info
- Submits concept text as new query
- Query item shows pivot indicator

**Flow:**
```
User clicks "epistemic capture" in response
    ↓
ExploreShell.handleConceptClick(span, sourceId)
    ↓
Create PivotContext { sourceResponseId, sourceText, sourceContext }
    ↓
useKineticStream.submit("epistemic capture", pivotContext)
    ↓
QueryItem renders with pivot indicator
    ↓
LLM receives context about the pivot
```

**Acceptance Criteria:**
- [ ] Click submits concept as query
- [ ] Pivot context attached to query
- [ ] Visual indicator shows it's a pivot
- [ ] LLM system prompt includes pivot context

**Tests:**
- E2E: Click concept → see new query → see response

---

### Story 3.5: Implement Fork Selection

**Task:** Make fork button clicks submit appropriate actions.

**Files to MODIFY:**
- `src/surface/components/KineticStream/ExploreShell.tsx`

**Implementation Notes:**
- `onForkSelect` handler in ExploreShell
- Fork type determines action:
  - `deep_dive`: Submit `queryPayload` as query
  - `pivot`: Submit with pivot context
  - `apply`: Navigate to journey/waypoint (future)
  - `challenge`: Submit challenge prompt

**Acceptance Criteria:**
- [ ] Fork click triggers appropriate action
- [ ] Deep dive submits query
- [ ] UI responds to selection
- [ ] Loading state during generation

**Tests:**
- E2E: Click fork → see response

---

### Story 3.6: Create Explore Baseline Test

**Task:** Create visual regression test for the explore experience.

**Files to CREATE:**
- `tests/e2e/explore-baseline.spec.ts`

**Implementation Notes:**
- Capture shell layout
- Capture response with concepts
- Capture response with forks
- Capture command console

**Test Cases:**
1. Empty shell state
2. Single response with concepts
3. Response with navigation forks
4. Loading state
5. Multi-turn conversation

**Acceptance Criteria:**
- [ ] All baseline images captured
- [ ] Tests pass on clean run
- [ ] Snapshot directory committed

**Tests:**
- Self (visual regression)

---

### Epic 3 Build Gate

```bash
# All tests pass
npm run build
npm test
npx playwright test

# Specific explore tests
npx playwright test tests/e2e/explore*.spec.ts

# Visual baselines updated
npx playwright test tests/e2e/explore-baseline.spec.ts --update-snapshots
git add tests/e2e/explore-baseline.spec.ts-snapshots/
```

---

## Final Sprint Gate

### Completion Checklist

- [ ] Route `/explore` loads without errors
- [ ] User can submit query via CommandConsole
- [ ] Response streams with glass styling
- [ ] Concepts render as orange spans (when parsed)
- [ ] Forks render at response bottom (when present)
- [ ] Concept click submits as pivot query
- [ ] Fork click submits appropriate query
- [ ] No imports from `components/Terminal/`
- [ ] All tests pass
- [ ] Visual baselines captured

### Verification Commands

```bash
# Full build
npm run build

# All tests
npm test
npx playwright test

# Terminal import check
grep -r "from.*components/Terminal" src/surface/components/KineticStream/
# Expected: empty

# Route check
curl -s http://localhost:5173/explore | head -20

# Visual regression
npx playwright test tests/e2e/explore-baseline.spec.ts
```

### Definition of Done

The sprint is **complete** when:

1. A user can navigate to `/explore`
2. Submit a question
3. See a streaming response in a glass container
4. See orange concept highlights (if LLM includes bold text)
5. Click a concept to pivot
6. See navigation forks (if LLM includes `<navigation>` block)
7. Click a fork to continue exploration

**The experience works end-to-end without touching Terminal.**

---

## Post-Sprint: Migration Path

Once Kinetic Experience v1 is stable:

1. **Feature flag:** Route `/terminal` to `/explore` for beta users
2. **Telemetry:** Compare engagement metrics
3. **Polish sprint:** Add missing features (lens, journey, overlays)
4. **Deprecation:** Archive `components/Terminal/` when parity achieved

---

*Sprint breakdown complete. Proceed to EXECUTION_PROMPT.md for handoff.*
